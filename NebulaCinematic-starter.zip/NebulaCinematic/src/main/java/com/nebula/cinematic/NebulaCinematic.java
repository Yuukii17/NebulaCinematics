package com.nebula.cinematic;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class NebulaCinematic extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getLogger().info("NebulaCinematic starter enabled.");
        getLogger().warning("Starter build only: cinematic camera, body pose, and blinking are NOT implemented yet.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("nebula")) {
            return false;
        }

        if (!sender.hasPermission("nebulacinematic.admin")) {
            sender.sendMessage("You don't have permission to use this command.");
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage("NebulaCinematic configuration reloaded.");
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("status")) {
            sender.sendMessage("NebulaCinematic starter is enabled.");
            sender.sendMessage("Cinematic features are not implemented in this starter build.");
            return true;
        }

        sender.sendMessage("Usage: /nebula <reload|status>");
        return true;
    }
}
