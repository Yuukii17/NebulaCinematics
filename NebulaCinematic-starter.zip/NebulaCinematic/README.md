# NebulaCinematic — starter project

Target: Paper 26.3, Java 25.

## Important status notice

This is a **starter project**, not the finished cinematic plugin. It currently:
- loads `config.yml`;
- registers `/nebula reload` and `/nebula status`;
- declares the planned configuration for body, camera, blinking, transition, and sounds.

It does **not** yet implement:
- a visible lying player body / player-skin mannequin;
- a freely controlled client camera;
- eye-blink screen transitions;
- death-event integration or Denizen handoff.

Those features require additional implementation and in-game testing. Do not treat this starter as the requested finished plugin.

## Build

Install JDK 25 and Gradle 8.10+ (or open this folder in IntelliJ IDEA and let its Gradle integration configure the project).

Run:

```bash
gradle build
```

The output JAR should be in `build/libs/`.

The Paper API dependency uses a version pattern for the 26.3 line. If Gradle cannot resolve it, check the current Paper 26.3 API version published in the Paper Maven repository and update the dependency version in `build.gradle.kts`.

## Install

Only after a successful build:
1. Stop the server.
2. Upload the JAR from `build/libs/` to `plugins/`.
3. Start the server.
4. Check the console for `NebulaCinematic starter enabled.`

## Commands

- `/nebula status`
- `/nebula reload`

Permission: `nebulacinematic.admin` (OP by default).
